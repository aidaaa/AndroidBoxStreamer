package com.example.androidbox;

import android.content.pm.ActivityInfo;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;

import com.google.android.exoplayer2.ExoPlayerFactory;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.source.ProgressiveMediaSource;
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector;
import com.google.android.exoplayer2.trackselection.TrackSelector;
import com.google.android.exoplayer2.ui.PlayerView;
import com.google.android.exoplayer2.upstream.DataSource;
import com.google.android.exoplayer2.upstream.DefaultDataSourceFactory;
import com.google.android.exoplayer2.upstream.DefaultHttpDataSourceFactory;
import com.google.android.exoplayer2.util.Util;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class ExoPlayerActivity extends AppCompatActivity {

    BottomNavigationView bottom_navigation;
    PlayerView pv;
    ImageView exo_fullscreen_icon;
    boolean fs=false;
    String filePath;
    TrackSelector trackSelector;
    SimpleExoPlayer exoPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exo_player);

        bottom_navigation=findViewById(R.id.bottom_navigation);
        pv=findViewById(R.id.pv);
        exo_fullscreen_icon=findViewById(R.id.exo_fullscreen_icon);

        trackSelector=new DefaultTrackSelector();
        exoPlayer= ExoPlayerFactory.newSimpleInstance(this,trackSelector);


        exo_fullscreen_icon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (fs)
                {
                    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
                    RelativeLayout.LayoutParams params= (RelativeLayout.LayoutParams) pv.getLayoutParams();
                    params.width=params.MATCH_PARENT;
                    params.height=params.MATCH_PARENT;
                    pv.setLayoutParams(params);
                    fs=false;
                }
                else
                {
                    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
                    RelativeLayout.LayoutParams params= (RelativeLayout.LayoutParams) pv.getLayoutParams();
                    params.width=params.MATCH_PARENT;
                    params.height=params.MATCH_PARENT;
                    pv.setLayoutParams(params);
                    fs=true;
                }
            }
        });

        bottom_navigation.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId())
                {
                    case R.id.action_recents:
                        filePath="http://192.168.10.74:3001/1";
                        setPlayer(filePath);
                        break;
                    case R.id.action_nearby:
                        filePath="http://192.168.10.74:3001/2";
                        setPlayer(filePath);
                        break;
                    case R.id.action_favorites:
                        filePath="http://192.168.10.74:3001/3";
                        setPlayer(filePath);
                        break;
                }

                return true;
            }
        });
    }

    private void setPlayer(String filePath)
    {
        Uri uri=Uri.parse(filePath);
        if (exoPlayer.isPlaying())
        {
            exoPlayer.stop(true);
            exoPlayer.release();
            exoPlayer=ExoPlayerFactory.newSimpleInstance(this,trackSelector);
        }
        pv.setPlayer(exoPlayer);
        DataSource.Factory dFactory=new DefaultHttpDataSourceFactory(Util.getUserAgent(this,"exoplayer"));
        MediaSource mediaSource=new ProgressiveMediaSource.Factory(dFactory).createMediaSource(uri);
        exoPlayer.prepare(mediaSource);
    }
}
